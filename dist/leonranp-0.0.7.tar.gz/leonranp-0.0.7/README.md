# Leon Random Plus

This is Leon Random Plus,that add more functions to the random!

To use it,code "import leonranp"

This package can use with random.

## Website

Wiki:http://leonmmcoset.jjmm.ink:8002/doku.php?id=leonranp

To upgrade,use "leonranp.upgrade()"

To delete Leon Random Plus,use "leonranp.dellrp()"

Copyright LeonMMcoset.All rights reserved.