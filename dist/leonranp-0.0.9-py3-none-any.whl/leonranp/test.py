from __init__ import *
randstr()
print('---')
print(randcode(120))
print('---')
a = randcode(6)
print(a)
b = input("aa")

if a == b:
    print("Yes")
else:
    print("No")
print('---')
a = randbool()
print(a)
upgrade()
print('---')
print(randlistcode(10))