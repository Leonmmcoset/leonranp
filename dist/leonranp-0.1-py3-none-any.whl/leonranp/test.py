from __init__ import *
print(randstrbs())
print('---')
print(randcodebs(5))