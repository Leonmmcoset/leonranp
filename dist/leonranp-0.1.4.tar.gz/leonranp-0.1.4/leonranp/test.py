from __init__ import *
print(randcodeall(20))