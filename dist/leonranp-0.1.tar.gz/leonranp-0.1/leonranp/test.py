from __init__ import *
crashidle()